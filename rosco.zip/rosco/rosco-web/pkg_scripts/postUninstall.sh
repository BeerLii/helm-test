#!/bin/sh

rm -rf /var/log/spinnaker/rosco
